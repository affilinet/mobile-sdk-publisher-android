package com.example.affilinet.publisherdemo;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

import com.rm.affilinet.SessionCallback;
import com.rm.affilinet.advertiser.Session;
import com.rm.affilinet.communication.Request;
import com.rm.affilinet.communication.RequestResponse;
import com.rm.affilinet.exceptions.SessionException;
import com.rm.affilinet.models.Platform;
import com.rm.affilinet.models.PublisherAccount;
import com.rm.affilinet.webservice.models.WSProductImageScale;
import com.rm.affilinet.webservice.models.WSShopIdMode;
import com.rm.affilinet.webservice.models.WSShopLogoScale;
import com.rm.affilinet.webservice.requests.GetCategoryListRequest;
import com.rm.affilinet.webservice.requests.GetProductsRequest;
import com.rm.affilinet.webservice.requests.GetShopListRequest;
import com.rm.affilinet.webservice.requests.SearchProductsRequest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        runPublisherTests();
    }

    private void runPublisherTests() {

        setContentView(R.layout.activity_main);

        List<Integer> list = new ArrayList<>();
        list.add(new Integer(661926));
        PublisherAccount account = new PublisherAccount(list, "2qgkL4yyHHOfQZU4cngo");
        Session session = Session.getInstance();

        try {
            session.open(getApplicationContext(), account, Platform.DE);
        } catch (Exception e) {
            Log.v("affilinet", e.getMessage());
        }

        GetCategoryListRequest req1 = new GetCategoryListRequest(session);
        req1.setShopId("0");

        GetShopListRequest req2 = new GetShopListRequest(session);
        long timestamp =  1388601005;
        timestamp *= 1000;
        req2.setUpdatedAfter(new Date(timestamp));
        req2.setLogoScale(WSShopLogoScale.NoLogo);

        GetProductsRequest req3 = new GetProductsRequest(session);

        List<WSProductImageScale> imagescales = new ArrayList<WSProductImageScale>();
        imagescales.add(WSProductImageScale.OriginalImage);
        imagescales.add(WSProductImageScale.Image60);

        List<WSShopLogoScale> logoscales = new ArrayList<WSShopLogoScale>();
        logoscales.add(WSShopLogoScale.NoLogo);
        logoscales.add(WSShopLogoScale.Logo120);

        List<String> productIDs = new ArrayList<String>();
        productIDs.add("493822602");
        productIDs.add("526068620");
        productIDs.add("437092183");

        req3.setProductIds(productIDs);
        req3.setImageScales(imagescales);
        req3.setLogoScales(logoscales);


        SearchProductsRequest req4 = new SearchProductsRequest(session);

        List<String> categoryIDs = new ArrayList<String>();
        categoryIDs.add("33388558");

        List<String> shopIds = new ArrayList<String>();
        shopIds.add("0");

        req4.setCategoryIds(categoryIDs);
        req4.setShopIds(shopIds);
        req4.setShopIdMode(WSShopIdMode.Include);

        List<Request> requests = new ArrayList<Request>();
        requests.add(req1);
        requests.add(req2);
        requests.add(req3);
        requests.add(req4);

        try {
            Session.getInstance().executeRequests(requests, new SessionCallback() {

                @Override
                public void onRequestsFinished() {
                    Log.v("affilinet", "Requests finished");
                }

                @Override
                public void onRequestsError(Error error) {
                    Log.v("affilinet", "Requests finished with error: " + error);
                }

                @Override
                public void onRequestResponse(Request request, RequestResponse response) {
                    if(response.error != null) {
                        Log.v("affilinet", String.format("Request %s finished with error %s", request.toString(), response.error.getMessage()));
                    }
                    else {
                        Log.v("affilinet", String.format("Request %s finished with response %s", request.toString(), response.toString()));
                    }
                }
            });
        } catch (SessionException e) {
            Log.v("affilinet", e.getMessage());
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

}
